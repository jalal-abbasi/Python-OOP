"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

print(id(15))

print(id("Hello, World!"))

print(id([1, 2, 3, 4]))

a = [1, 2, 3, 4, 5]
b = [1, 2, 3, 4, 5]

print(id(a))
print(id(b))