"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

a = [1, 6, 2, 6]
b = [1, 6, 2, 6]

print(a is b)

print(a == b)