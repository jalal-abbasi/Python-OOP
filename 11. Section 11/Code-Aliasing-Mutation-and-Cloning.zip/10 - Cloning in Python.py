"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

a = [1, 2, 3, 4]
b = a[:]

print(a)
print(b)

b[0] = 15

print(a)
print(b)