"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

class Polygon:
    pass


class Triangle(Polygon):
    pass