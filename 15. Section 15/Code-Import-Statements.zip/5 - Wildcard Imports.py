"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

from math import *

print(pi)
print(sin(54))
print(cos(34))
