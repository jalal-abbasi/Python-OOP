"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

def add(a, b):
    """Return the sum of a and b."""
    return a + b
