"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

result = 5 + 6
print(result) 

result = (5).__add__(6)
print(result) 
