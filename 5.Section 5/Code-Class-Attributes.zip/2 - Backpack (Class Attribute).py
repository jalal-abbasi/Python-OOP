"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

class Backpack:

    max_num_items = 10

    def __init__(self):
        self.items = []
