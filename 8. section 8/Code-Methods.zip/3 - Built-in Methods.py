"""
Course: Python OOP - Object Oriented Programming for Beginners
By: Estefania Cassingena Navone
"""

my_list = [4, 5, 6, 7, 8]

my_list.sort()
print(my_list)

my_list.append(14)
print(my_list)

my_list.extend([1, 2, 3])
print(my_list)

number = my_list.pop()
print(number)
print(my_list)
